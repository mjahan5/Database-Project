package com.example.sqlapplication;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Random;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final String url = "jdbc:mysql://192.168.1.67:3306/project1";
    private static final String user = "test";
    private static final String pass = "flower44";







    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DB();









    }


    public void DB() {
        TextView txt = (TextView) this.findViewById(R.id.textView);
        Button bt = (Button) this.findViewById(R.id.button2);


        try {

            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);

            String result = "Your Movie Choice is:\n";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("Select m.Tittle, m.Year_released, g.genre, r.Rated, d.Director, k.Review, k.Rating  "
                    + "FROM movie AS m, rating As r, review AS k, genre AS g, director AS d "
                    + "WHERE m.genre_fk = g.id_genre "
                    + "AND m.review_fk = k.ID_Review "
                    + "AND m.rate_fk = r.idRating "
                    + "AND m.director_fk = d.id_director "
                    + "ORDER BY RAND() LIMIT 1");

            ResultSetMetaData rsmd = rs.getMetaData();


            while (rs.next()) {

                result += rsmd.getColumnName(1) + ": " + rs.getString(1) + "\n";

                result += rsmd.getColumnName(2) + ": " + rs.getString(2) + "\n";

                result += rsmd.getColumnName(3) + ": " + rs.getString(3) + "\n";

                result += rsmd.getColumnName(4) + ": " + rs.getString(4) + "\n";

                result += rsmd.getColumnName(5) + ": " + rs.getString(5) + "\n";

                result += rsmd.getColumnName(6) + ": " + rs.getString(6) + "\n";

                result += rsmd.getColumnName(7) + ": " + rs.getString(7) + "\n";
            }


            String finalResult = result;
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    txt.setText(finalResult);
                    long mLastClickTime = 0;
                    if ((SystemClock.elapsedRealtime() - mLastClickTime) < 1000) {
                        return;
                    }
                    mLastClickTime = SystemClock.elapsedRealtime();





                }

            });




        } catch (Exception e) {
            e.printStackTrace();
            txt.setText(e.toString());


          /*  if (Build.VERSION.SDK_INT > 9) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);*/
            }


        }


    }








